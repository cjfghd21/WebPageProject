1. Cheolhong Ahn (cahn12)

2. App Description.

Uses NASA's APOD API to retrive picture of the day on the given input date by the user 
then shows the picture and its description.

When the user enters valid date and pciture is retrieved, the information is saved on MongoDB for the
user to review later untill user clears search history.

3. API Link
https://api.nasa.gov/planetary/apod

(api key can be generated from https://api.nasa.gov/
 although app should work with included api key)

4. Youtube Link

https://youtu.be/UTf2Tqik-Ek